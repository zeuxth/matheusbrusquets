import { MainNav } from "@/components/layout/main-nav"
import { OrderFilters } from "@/components/orders/order-filters"
import { OrderForm } from "@/components/orders/order-form"
import { OrdersTable } from "@/components/orders/orders-table"
import { Order } from "@/types/orders"

// Sample data - in a real app, this would come from an API
const orders: Order[] = [
  {
    id: "8779",
    customer: {
      name: "Fernando Nunes",
      phone: "5599999999999"
    },
    items: [
      { name: "Blend Alcatra", quantity: 1, price: 24.00 }
    ],
    total: 24.00,
    paymentMethod: "Dinheiro",
    status: "Pendente",
    createdAt: new Date("2024-12-29T16:25:00"),
    isPOS: true
  },
  {
    id: "4594",
    customer: {
      name: "Cliente Balcão",
      phone: ""
    },
    items: [
      { name: "X-Bacon", quantity: 1, price: 23.00 }
    ],
    total: 23.00,
    paymentMethod: "Pendente de Pagamento",
    status: "Pronto para Entrega",
    createdAt: new Date("2024-12-29T16:24:00"),
    isPOS: true,
    tableNumber: "1"
  }
]

export default function OrdersPage() {
  return (
    <div className="flex h-screen bg-gray-100">
      <MainNav />
      <main className="flex-1 p-8 overflow-auto">
        <div className="space-y-8">
          <OrderFilters />
          <div className="grid gap-8 lg:grid-cols-[1fr,400px]">
            <div className="space-y-4">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <span className="text-red-600">🛒</span>
                Gestão de Pedidos
              </h2>
              <OrdersTable orders={orders} />
            </div>
            <OrderForm />
          </div>
        </div>
      </main>
    </div>
  )
}

