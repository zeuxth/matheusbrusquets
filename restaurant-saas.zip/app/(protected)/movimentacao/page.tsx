import { MainNav } from "@/components/layout/main-nav"
import { DeliveryMetrics } from "@/components/delivery/delivery-metrics"
import { DeliverySettings } from "@/components/delivery/delivery-settings"
import { DeliveryPeople } from "@/components/delivery/delivery-people"
import { DeliveriesTables } from "@/components/delivery/deliveries-tables"

export default function DeliveryPage() {
  return (
    <div className="flex h-screen bg-gray-100">
      <MainNav />
      <main className="flex-1 p-8 overflow-auto">
        <div className="space-y-8">
          <DeliveryMetrics />
          <div className="grid gap-8 lg:grid-cols-2">
            <DeliverySettings />
            <DeliveryPeople />
          </div>
          <DeliveriesTables />
        </div>
      </main>
    </div>
  )
}

