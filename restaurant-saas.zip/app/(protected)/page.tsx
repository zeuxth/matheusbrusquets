import { MainNav } from "@/components/layout/main-nav"
import { MetricCards } from "@/components/dashboard/metric-cards"
import { RecentOrders } from "@/components/dashboard/recent-orders"

export default function DashboardPage() {
  return (
    <div className="flex h-screen bg-gray-100">
      <MainNav />
      <main className="flex-1 p-8 overflow-auto">
        <div className="space-y-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              Bem-vindo ao Delivery PRO [Versão Demo]
            </h1>
            <p className="text-gray-500">
              Gestão e automação para pedidos e entregas!
            </p>
          </div>
          <MetricCards />
          <RecentOrders />
        </div>
      </main>
    </div>
  )
}

