import { Suspense } from 'react'
import { redirect } from 'next/navigation'
import { getUser } from '@/lib/auth'
import { MainNav } from "@/components/layout/main-nav"
import { Loader2 } from 'lucide-react'

async function AuthCheck() {
  const user = await getUser()
  if (!user) {
    redirect('/login')
  }
  return null
}

export default function ProtectedLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="flex h-screen bg-gray-100">
      <Suspense fallback={<AuthCheckFallback />}>
        <AuthCheck />
      </Suspense>
      <MainNav />
      <main className="flex-1 p-8 overflow-auto">
        <Suspense fallback={<LoadingFallback />}>
          {children}
        </Suspense>
      </main>
    </div>
  )
}

function AuthCheckFallback() {
  return <LoadingFallback message="Verificando autenticação..." />
}

function LoadingFallback({ message = "Carregando..." }) {
  return (
    <div className="flex items-center justify-center w-full h-full">
      <div className="text-center">
        <Loader2 className="w-10 h-10 animate-spin text-red-600 mx-auto mb-4" />
        <p className="text-gray-500">{message}</p>
      </div>
    </div>
  )
}

