import { MainNav } from "@/components/layout/main-nav"
import { ExportButtons } from "@/components/reports/export-buttons"
import { SalesChart } from "@/components/reports/sales-chart"
import { OrderStatusChart } from "@/components/reports/order-status-chart"
import { BestSellingProducts } from "@/components/reports/best-selling-products"
import { PaymentMethods } from "@/components/reports/payment-methods"
import { Neighborhoods } from "@/components/reports/neighborhoods"
import { HourlyDistribution } from "@/components/reports/hourly-distribution"
import { FinancialKPIs } from "@/components/reports/financial-kpis"
import { ProfitabilityTable } from "@/components/reports/profitability-table"
import { EarningsCalendar } from "@/components/reports/earnings-calendar"

export default function ReportsPage() {
  return (
    <div className="flex h-screen bg-gray-100">
      <MainNav />
      <main className="flex-1 p-8 overflow-auto">
        <div className="space-y-8">
          <ExportButtons />
          
          <div className="grid gap-8 md:grid-cols-2">
            <SalesChart />
            <OrderStatusChart />
          </div>

          <div className="grid gap-8 md:grid-cols-2">
            <BestSellingProducts />
            <div className="space-y-8">
              <PaymentMethods />
              <Neighborhoods />
            </div>
          </div>

          <HourlyDistribution />

          <div className="space-y-8">
            <h2 className="text-lg font-semibold">KPIs Financeiros (Últimos 30 dias)</h2>
            <FinancialKPIs />
          </div>

          <ProfitabilityTable />
          <EarningsCalendar />
        </div>
      </main>
    </div>
  )
}

