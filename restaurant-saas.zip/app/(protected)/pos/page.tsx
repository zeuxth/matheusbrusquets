"use client"

import { useState } from "react"
import { MainNav } from "@/components/layout/main-nav"
import { ProductSearch } from "@/components/pos/product-search"
import { ProductList } from "@/components/pos/product-list"
import { Cart } from "@/components/pos/cart"
import { Tables } from "@/components/pos/tables"
import type { CartItem, Category, Product, Table } from "@/types/pos"

const categories: Category[] = [
  {
    name: "Hamburgueres tradicional",
    icon: "🍔",
    products: [
      { id: "1", name: "X-Bacon", price: 23.00, category: "traditional", icon: "🍔" },
      { id: "2", name: "X-Salada", price: 18.00, category: "traditional", icon: "🍔" },
      { id: "3", name: "X-Tudo", price: 25.00, category: "traditional", icon: "🍔" },
    ]
  },
  {
    name: "Hamburguer Artesanal",
    icon: "🍔",
    products: [
      { id: "4", name: "Blend Alcatra", price: 24.00, category: "artesanal", icon: "🍔" },
      { id: "5", name: "Blend Bovino", price: 19.90, category: "artesanal", icon: "🍔" },
    ]
  },
  {
    name: "Porções",
    icon: "🍟",
    products: [
      { id: "6", name: "Batata - 200g", price: 10.00, category: "portions", icon: "🍟" },
      { id: "7", name: "Porção Mista", price: 25.00, category: "portions", icon: "🍟" },
    ]
  },
  {
    name: "Refrigerantes e Bebidas",
    icon: "🥤",
    products: [
      { id: "8", name: "Coca-Cola Lata 350ML", price: 6.00, category: "drinks", icon: "🥤" },
      { id: "9", name: "Guarana Antarctica 350ML", price: 5.00, category: "drinks", icon: "🥤" },
    ]
  }
]

const initialTables: Table[] = Array.from({ length: 9 }, (_, i) => ({
  id: i + 1,
  name: `Mesa ${i + 1}`,
  status: i === 0 ? "occupied" : "available"
}))

export default function POSPage() {
  const [cartItems, setCartItems] = useState<CartItem[]>([])
  const [tables, setTables] = useState<Table[]>(initialTables)
  const [searchQuery, setSearchQuery] = useState("")

  const handleAddToCart = (product: Product) => {
    setCartItems(current => {
      const existing = current.find(item => item.id === product.id)
      if (existing) {
        return current.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      }
      return [...current, { ...product, quantity: 1 }]
    })
  }

  const handleClearCart = () => {
    setCartItems([])
  }

  const handleFinishSale = () => {
    // Implement sale finalization logic
    handleClearCart()
  }

  const handleSelectTable = (table: Table) => {
    // Implement table selection logic
  }

  const filteredCategories = categories.map(category => ({
    ...category,
    products: category.products.filter(product =>
      product.name.toLowerCase().includes(searchQuery.toLowerCase())
    )
  })).filter(category => category.products.length > 0)

  return (
    <div className="flex h-screen bg-gray-100">
      <MainNav />
      <main className="flex-1 p-8 overflow-auto">
        <div className="grid gap-8 lg:grid-cols-[1fr,400px]">
          <div className="space-y-6">
            <ProductSearch onSearch={setSearchQuery} />
            <ProductList
              categories={filteredCategories}
              onAddToCart={handleAddToCart}
            />
          </div>
          <div className="space-y-8">
            <Cart
              items={cartItems}
              onClearCart={handleClearCart}
              onFinishSale={handleFinishSale}
            />
            <Tables
              tables={tables}
              onSelectTable={handleSelectTable}
            />
          </div>
        </div>
      </main>
    </div>
  )
}

