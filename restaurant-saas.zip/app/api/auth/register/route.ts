import { NextResponse } from 'next/server'
import { createUser, generateToken } from '@/lib/auth'

export async function POST(request: Request) {
  const { email, password, name } = await request.json()
  try {
    const user = await createUser(email, password, name)
    const token = generateToken(user)
    return NextResponse.json({ token })
  } catch (error) {
    return NextResponse.json({ error: 'Registration failed' }, { status: 400 })
  }
}

