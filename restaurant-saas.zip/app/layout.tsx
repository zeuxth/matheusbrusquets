import { Inter } from 'next/font/google'
import { AuthProvider } from '@/components/providers/auth-provider'
import { ErrorBoundary } from 'react-error-boundary'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

function ErrorFallback({ error }: { error: Error }) {
  return (
    <div className="flex items-center justify-center min-h-screen bg-red-50">
      <div className="p-8 bg-white rounded shadow-xl">
        <h1 className="text-2xl font-bold text-red-600 mb-4">Oops! Algo deu errado.</h1>
        <p className="text-gray-600 mb-4">{error.message}</p>
        <button
          onClick={() => window.location.reload()}
          className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 transition-colors"
        >
          Tentar novamente
        </button>
      </div>
    </div>
  )
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR">
      <body className={inter.className}>
        <ErrorBoundary FallbackComponent={ErrorFallback}>
          <AuthProvider>{children}</AuthProvider>
        </ErrorBoundary>
      </body>
    </html>
  )
}

