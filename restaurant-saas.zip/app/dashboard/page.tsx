'use client'

import { useState, useEffect } from 'react'
import { Menu } from '@/components/Menu'
import { Restaurant } from '@prisma/client'

export default function Dashboard() {
  const [restaurant, setRestaurant] = useState<Restaurant | null>(null)

  useEffect(() => {
    // In a real app, you'd fetch the restaurant data for the logged-in user
    fetch('/api/restaurants/me')
      .then(res => res.json())
      .then(data => setRestaurant(data))
  }, [])

  if (!restaurant) {
    return <div>Loading...</div>
  }

  return (
    <div className="container mx-auto px-4">
      <h1 className="text-3xl font-bold mb-4">Dashboard</h1>
      <h2 className="text-2xl font-semibold mb-2">{restaurant.name}</h2>
      <Menu restaurantId={restaurant.id} />
    </div>
  )
}

