import { Bike, DollarSign, Package, PackageCheck } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface MetricCardProps {
  title: string
  value: string
  icon: React.ReactNode
  className?: string
}

function MetricCard({ title, value, icon, className }: MetricCardProps) {
  return (
    <Card className={className}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-white">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold text-white">{value}</div>
      </CardContent>
    </Card>
  )
}

export function DeliveryMetrics() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <MetricCard
        title="Entregas Hoje"
        value="0"
        icon={<Package className="h-4 w-4 text-white" />}
        className="bg-cyan-500"
      />
      <MetricCard
        title="Entregas Concluídas"
        value="0"
        icon={<PackageCheck className="h-4 w-4 text-white" />}
        className="bg-emerald-600"
      />
      <MetricCard
        title="Total em Taxas"
        value="R$ 0,00"
        icon={<DollarSign className="h-4 w-4 text-white" />}
        className="bg-blue-600"
      />
      <MetricCard
        title="Entregadores Ativos"
        value="1"
        icon={<Bike className="h-4 w-4 text-white" />}
        className="bg-yellow-500"
      />
    </div>
  )
}

