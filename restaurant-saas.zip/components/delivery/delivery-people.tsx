import { Pencil, Plus, Trash2 } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { DeliveryPerson } from "@/types/delivery"
import { useState } from 'react';

export function DeliveryPeople() {
  const [deliveryPeople, setDeliveryPeople] = useState<DeliveryPerson[]>([
  {
    name: "João Silva",
    phone: "5562998034529",
    vehicle: "Moto Honda CG 160 Start",
    status: "Em Entrega"
  },
  {
    name: "Igor Santos",
    phone: "5562998034529",
    vehicle: "Moto Honda Biz 110i",
    status: "Ativo"
  }
])

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Entregadores</CardTitle>
        <Button className="bg-red-600 hover:bg-red-700 gap-2">
          <Plus className="h-4 w-4" />
          Novo Entregador
        </Button>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <table className="w-full">
            <thead>
              <tr className="bg-red-600 text-white">
                <th className="p-2 text-left">Nome</th>
                <th className="p-2 text-left">Telefone</th>
                <th className="p-2 text-left">Veículo</th>
                <th className="p-2 text-left">Status</th>
                <th className="p-2 text-left">Ações</th>
              </tr>
            </thead>
            <tbody>
              {deliveryPeople.map((person) => (
                <tr key={person.name} className="border-t">
                  <td className="p-2">{person.name}</td>
                  <td className="p-2">{person.phone}</td>
                  <td className="p-2">{person.vehicle}</td>
                  <td className="p-2">
                    <Badge
                      className={
                        person.status === "Ativo"
                          ? "bg-emerald-100 text-emerald-700"
                          : "bg-yellow-100 text-yellow-700"
                      }
                    >
                      {person.status}
                    </Badge>
                  </td>
                  <td className="p-2">
                    <div className="flex gap-2">
                      <Button variant="ghost" size="icon">
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="text-red-600">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  )
}

