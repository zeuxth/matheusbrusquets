"use client"

import { useState } from 'react'
import { Plus, Trash2 } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import type { DeliveryRegion, BusinessHours } from "@/types/delivery"

export function DeliverySettings() {
  const [regions, setRegions] = useState<DeliveryRegion[]>([
    { name: "Centro", fee: 10.00 },
    { name: "Norte", fee: 12.00 },
    { name: "Sul", fee: 15.00 },
    { name: "Retirada Loja", fee: 0.00 },
  ])

  const [businessHours, setBusinessHours] = useState<BusinessHours>({
    start: "18:00",
    end: "23:59",
    workingDays: ["Domingo", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"]
  })

  const handleRegionChange = (index: number, field: 'name' | 'fee', value: string | number) => {
    const newRegions = [...regions]
    newRegions[index][field] = field === 'fee' ? Number(value) : value
    setRegions(newRegions)
  }

  const handleRemoveRegion = (index: number) => {
    const newRegions = regions.filter((_, i) => i !== index)
    setRegions(newRegions)
  }

  const handleAddRegion = () => {
    setRegions([...regions, { name: "", fee: 0 }])
  }

  const handleBusinessHoursChange = (field: keyof BusinessHours, value: string | string[]) => {
    setBusinessHours(prev => ({ ...prev, [field]: value }))
  }

  const toggleWorkingDay = (day: string) => {
    setBusinessHours(prev => ({
      ...prev,
      workingDays: prev.workingDays.includes(day)
        ? prev.workingDays.filter(d => d !== day)
        : [...prev.workingDays, day]
    }))
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Configurações de Entrega</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <h3 className="font-medium">Taxas de Entrega por Região</h3>
          <div className="space-y-2">
            {regions.map((region, index) => (
              <div key={index} className="flex items-center justify-between gap-4">
                <Input 
                  value={region.name} 
                  onChange={(e) => handleRegionChange(index, 'name', e.target.value)}
                  className="flex-1" 
                />
                <div className="flex items-center gap-2">
                  <span className="text-sm">R$</span>
                  <Input 
                    value={region.fee.toFixed(2)}
                    onChange={(e) => handleRegionChange(index, 'fee', e.target.value)}
                    type="number"
                    step="0.01"
                    className="w-32" 
                  />
                </div>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="text-red-600"
                  onClick={() => handleRemoveRegion(index)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
          <Button variant="outline" className="gap-2" onClick={handleAddRegion}>
            <Plus className="h-4 w-4" />
            Adicionar Região
          </Button>
        </div>

        <div className="space-y-4">
          <h3 className="font-medium">Horário de Funcionamento</h3>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="start-time">Horário de Início</Label>
              <Input
                id="start-time"
                type="time"
                value={businessHours.start}
                onChange={(e) => handleBusinessHoursChange('start', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="end-time">Horário de Fim</Label>
              <Input
                id="end-time"
                type="time"
                value={businessHours.end}
                onChange={(e) => handleBusinessHoursChange('end', e.target.value)}
              />
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="font-medium">Dias de Funcionamento</h3>
          <div className="flex flex-wrap gap-4">
            {["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"].map((day) => (
              <div key={day} className="flex items-center space-x-2">
                <Checkbox 
                  id={day} 
                  checked={businessHours.workingDays.includes(day)}
                  onCheckedChange={() => toggleWorkingDay(day)}
                />
                <Label htmlFor={day}>{day}</Label>
              </div>
            ))}
          </div>
        </div>

        <Button className="w-full bg-red-600 hover:bg-red-700">
          Salvar Configurações
        </Button>
      </CardContent>
    </Card>
  )
}

