import { Eye, Ban, MessageCircle } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import type { Delivery } from "@/types/delivery"
import { useState } from 'react';

const [activeDeliveries, setActiveDeliveries] = useState<Delivery[]>([
  {
    id: "006821",
    customer: {
      name: "Lucia Faria Gomes",
      phone: "5599999999992"
    },
    address: "Rua Francisco Régis Maciel de Melo, Equatorial",
    deliveryPerson: "João Silva",
    status: "Em Rota",
    time: "07:21"
  },
  {
    id: "007013",
    customer: {
      name: "Bruno Souza",
      phone: "5599999999994"
    },
    address: "Rua Brasil, Vitor Braga",
    status: "Aguardando"
  }
])

const [completedDeliveries] = useState<Delivery[]>([
  {
    id: "008163",
    customer: {
      name: "Lorena Evelyn Silveira",
      phone: "5599999999993"
    },
    address: "Rua Gonzaga Júnior, Tancredo Neves - Número 14",
    deliveryPerson: "João Silva",
    status: "Entregue",
    time: "00:00",
    fee: 10.00
  }
])

export function DeliveriesTables() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Entregas em Andamento</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <table className="w-full">
              <thead>
                <tr className="bg-red-600 text-white">
                  <th className="p-2 text-left">Pedido</th>
                  <th className="p-2 text-left">Cliente</th>
                  <th className="p-2 text-left">Endereço</th>
                  <th className="p-2 text-left">Entregador</th>
                  <th className="p-2 text-left">Status</th>
                  <th className="p-2 text-left">Tempo</th>
                  <th className="p-2 text-left">Ações</th>
                </tr>
              </thead>
              <tbody>
                {activeDeliveries.map((delivery) => (
                  <tr key={delivery.id} className="border-t">
                    <td className="p-2">#{delivery.id}</td>
                    <td className="p-2">
                      <div>
                        {delivery.customer.name}
                        <div className="text-sm text-gray-500">{delivery.customer.phone}</div>
                      </div>
                    </td>
                    <td className="p-2">{delivery.address}</td>
                    <td className="p-2">
                      {delivery.deliveryPerson || (
                        <Select onValueChange={(value) => {
                          const newDeliveries = [...activeDeliveries]
                          const index = newDeliveries.findIndex(d => d.id === delivery.id)
                          newDeliveries[index].deliveryPerson = value === "joao" ? "João Silva" : "Igor Santos"
                          setActiveDeliveries(newDeliveries)
                        }}>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecionar..." />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="joao">João Silva</SelectItem>
                            <SelectItem value="igor">Igor Santos</SelectItem>
                          </SelectContent>
                        </Select>
                      )}
                    </td>
                    <td className="p-2">
                      <Badge
                        className={
                          delivery.status === "Em Rota"
                            ? "bg-red-100 text-red-700"
                            : "bg-yellow-100 text-yellow-700"
                        }
                      >
                        {delivery.status}
                      </Badge>
                    </td>
                    <td className="p-2">{delivery.time || "--:--"}</td>
                    <td className="p-2">
                      <div className="flex gap-2">
                        {delivery.status === "Em Rota" && (
                          <Button className="bg-emerald-600 hover:bg-emerald-700">
                            Entregue
                          </Button>
                        )}
                        <Button variant="destructive">
                          Cancelar
                        </Button>
                        <Button variant="ghost" size="icon">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="text-green-600">
                          <MessageCircle className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-2 text-sm text-gray-500">
            Mostrando 1-2 de 2 entregas
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Entregas Finalizadas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <table className="w-full">
              <thead>
                <tr className="bg-red-600 text-white">
                  <th className="p-2 text-left">Pedido</th>
                  <th className="p-2 text-left">Cliente</th>
                  <th className="p-2 text-left">Endereço</th>
                  <th className="p-2 text-left">Entregador</th>
                  <th className="p-2 text-left">Tempo Total</th>
                  <th className="p-2 text-left">Taxa</th>
                  <th className="p-2 text-left">Status</th>
                </tr>
              </thead>
              <tbody>
                {completedDeliveries.map((delivery) => (
                  <tr key={delivery.id} className="border-t">
                    <td className="p-2">#{delivery.id}</td>
                    <td className="p-2">
                      <div>
                        {delivery.customer.name}
                        <div className="text-sm text-gray-500">{delivery.customer.phone}</div>
                      </div>
                    </td>
                    <td className="p-2">{delivery.address}</td>
                    <td className="p-2">{delivery.deliveryPerson}</td>
                    <td className="p-2">{delivery.time}</td>
                    <td className="p-2">R$ {delivery.fee?.toFixed(2)}</td>
                    <td className="p-2">
                      <Badge className="bg-emerald-100 text-emerald-700">
                        {delivery.status}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-2 text-sm text-gray-500">
            Mostrando 1-1 de 1 entregas
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

