import { Bike, Clock, ShoppingCart, TrendingUp } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface MetricCardProps {
  title: string
  value: string
  subValue?: string
  icon: React.ReactNode
  className?: string
}

function MetricCard({ title, value, subValue, icon, className }: MetricCardProps) {
  return (
    <Card className={className}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        {subValue && (
          <p className="text-xs text-muted-foreground">{subValue}</p>
        )}
      </CardContent>
    </Card>
  )
}

export function MetricCards() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <MetricCard
        title="Vendas Hoje"
        value="R$ 0,00"
        subValue="0 pedidos"
        icon={<ShoppingCart className="h-4 w-4 text-blue-600" />}
        className="bg-blue-50"
      />
      <MetricCard
        title="Vendas do Mês"
        value="R$ 0,00"
        subValue="0 pedidos"
        icon={<TrendingUp className="h-4 w-4 text-emerald-600" />}
        className="bg-emerald-50"
      />
      <MetricCard
        title="Pedidos Pendentes"
        value="3"
        subValue="Aguardando preparo"
        icon={<Clock className="h-4 w-4 text-yellow-600" />}
        className="bg-yellow-50"
      />
      <MetricCard
        title="Em Rota"
        value="1"
        subValue="Pedidos em rota"
        icon={<Bike className="h-4 w-4 text-cyan-600" />}
        className="bg-cyan-50"
      />
    </div>
  )
}

