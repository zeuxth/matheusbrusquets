import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"

interface Order {
  id: string
  customer: string
  total: string
  status: "pending" | "ready" | "delivered"
}

const orders: Order[] = [
  {
    id: "#8779",
    customer: "Fernando Nunes",
    total: "24,00",
    status: "pending"
  },
  {
    id: "#4594",
    customer: "Cliente Balcão",
    total: "23,00",
    status: "ready"
  },
  {
    id: "#4121",
    customer: "Cliente Balcão",
    total: "10,00",
    status: "ready"
  },
  {
    id: "#8547",
    customer: "Nilza Baptista",
    total: "30,00",
    status: "delivered"
  },
  {
    id: "#6821",
    customer: "Lucia Faria Gomes",
    total: "18,00",
    status: "ready"
  }
]

const statusMap = {
  pending: { label: "Pendente", className: "bg-yellow-200 text-yellow-700" },
  ready: { label: "Pronto para Entrega", className: "bg-blue-200 text-blue-700" },
  delivered: { label: "Entregue", className: "bg-emerald-200 text-emerald-700" }
}

export function RecentOrders() {
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">Vendas Recentes</h2>
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Pedido</TableHead>
              <TableHead>Cliente</TableHead>
              <TableHead>Total</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {orders.map((order) => (
              <TableRow key={order.id}>
                <TableCell>{order.id}</TableCell>
                <TableCell>{order.customer}</TableCell>
                <TableCell>R$ {order.total}</TableCell>
                <TableCell>
                  <Badge className={statusMap[order.status].className}>
                    {statusMap[order.status].label}
                  </Badge>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

