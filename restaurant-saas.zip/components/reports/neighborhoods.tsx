"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import type { Neighborhood } from "@/types/reports"

const data: Neighborhood[] = [
  { name: "N/A", orders: 3, total: 57.00 },
  { name: "Vitor Braga", orders: 1, total: 34.00 },
  { name: "Tancredo Neves", orders: 1, total: 30.00 },
  { name: "Santa Maria", orders: 1, total: 25.00 },
  { name: "Floresta Sul", orders: 1, total: 29.90 },
  { name: "Dom Bosco", orders: 1, total: 39.00 }
]

export function Neighborhoods() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Bairros Mais Atendidos</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[300px] mb-6">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={data}
              layout="vertical"
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis type="number" />
              <YAxis dataKey="name" type="category" />
              <Tooltip />
              <Bar dataKey="orders" fill="#ef4444" />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Bairro</TableHead>
                <TableHead>Pedidos</TableHead>
                <TableHead>Total</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((neighborhood) => (
                <TableRow key={neighborhood.name}>
                  <TableCell>{neighborhood.name}</TableCell>
                  <TableCell>{neighborhood.orders}</TableCell>
                  <TableCell>R$ {neighborhood.total.toFixed(2)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}

