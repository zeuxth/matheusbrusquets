import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import type { EarningsCalendar } from "@/types/reports"

const data: EarningsCalendar[] = [
  {
    month: "Dezembro 2024",
    orders: 10,
    sales: 262.90,
    fees: 59.00,
    total: 321.90,
    averagePerOrder: 32.19
  }
]

export function EarningsCalendar() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Calendário de Ganhos</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow className="bg-red-600 text-white">
                <TableHead className="text-white">Mês</TableHead>
                <TableHead className="text-white">Pedidos</TableHead>
                <TableHead className="text-white">Vendas</TableHead>
                <TableHead className="text-white">Taxas</TableHead>
                <TableHead className="text-white">Total</TableHead>
                <TableHead className="text-white">Média por Pedido</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((row) => (
                <TableRow key={row.month}>
                  <TableCell>{row.month}</TableCell>
                  <TableCell>{row.orders}</TableCell>
                  <TableCell>R$ {row.sales.toFixed(2)}</TableCell>
                  <TableCell>R$ {row.fees.toFixed(2)}</TableCell>
                  <TableCell className="text-emerald-600">R$ {row.total.toFixed(2)}</TableCell>
                  <TableCell>R$ {row.averagePerOrder.toFixed(2)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}

