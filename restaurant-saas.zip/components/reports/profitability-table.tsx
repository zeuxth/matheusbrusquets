import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import type { MonthlyProfitability } from "@/types/reports"

const data: MonthlyProfitability[] = [
  {
    month: "Dec/2024",
    grossRevenue: 262.90,
    deliveryCosts: 59.00,
    netRevenue: 203.90,
    profitMargin: 77.56
  }
]

export function ProfitabilityTable() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Análise de Lucratividade Mensal</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow className="bg-red-600 text-white">
                <TableHead className="text-white">Mês</TableHead>
                <TableHead className="text-white">Receita Bruta</TableHead>
                <TableHead className="text-white">Custos Entrega</TableHead>
                <TableHead className="text-white">Receita Líquida</TableHead>
                <TableHead className="text-white">Margem de Lucro</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((row) => (
                <TableRow key={row.month}>
                  <TableCell>{row.month}</TableCell>
                  <TableCell>R$ {row.grossRevenue.toFixed(2)}</TableCell>
                  <TableCell>R$ {row.deliveryCosts.toFixed(2)}</TableCell>
                  <TableCell>R$ {row.netRevenue.toFixed(2)}</TableCell>
                  <TableCell>{row.profitMargin.toFixed(2)}%</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}

