import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import type { FinancialKPI } from "@/types/reports"

const data: FinancialKPI = {
  totalRevenue: 262.90,
  averageTicket: 26.29,
  deliveryCosts: 59.00
}

export function FinancialKPIs() {
  return (
    <div className="grid gap-4 md:grid-cols-3">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Receita Total</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">R$ {data.totalRevenue.toFixed(2)}</div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Ticket Médio</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">R$ {data.averageTicket.toFixed(2)}</div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Custos de Entrega</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">R$ {data.deliveryCosts.toFixed(2)}</div>
        </CardContent>
      </Card>
    </div>
  )
}

