"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import type { ProductSales } from "@/types/reports"

const data: ProductSales[] = [
  { name: "Blend Alcatra (1x)", quantity: 3, total: 97.00, icon: "🍔" },
  { name: "X-Salada (1x)", quantity: 3, total: 78.00, icon: "🍔" },
  { name: "X-Tudo (1x)", quantity: 1, total: 25.00, icon: "🍔" },
  { name: "Blend Bovino (1x)", quantity: 1, total: 29.90, icon: "🍔" },
  { name: "Batata - 200g (1x)", quantity: 1, total: 10.00, icon: "🍟" }
]

export function BestSellingProducts() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Produtos Mais Vendidos</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[300px] mb-6">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="quantity" fill="#ef4444" />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Produto</TableHead>
                <TableHead>Quantidade</TableHead>
                <TableHead>Total Vendas</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((product) => (
                <TableRow key={product.name}>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {product.icon} {product.name}
                    </div>
                  </TableCell>
                  <TableCell>{product.quantity}</TableCell>
                  <TableCell>R$ {product.total.toFixed(2)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}

