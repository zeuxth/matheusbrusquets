"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { PieChart, Pie, Cell, ResponsiveContainer, Legend } from 'recharts'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import type { PaymentMethod } from "@/types/reports"

const data: PaymentMethod[] = [
  { method: "Dinheiro", quantity: 4, total: 127.00, color: "#22c55e" },
  { method: "PIX", quantity: 2, total: 59.90, color: "#3b82f6" },
  { method: "Cartão", quantity: 2, total: 43.00, color: "#eab308" },
  { method: "Pendente de Pagamento", quantity: 2, total: 33.00, color: "#ef4444" }
]

export function PaymentMethods() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Formas de Pagamento</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[300px] mb-6">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                dataKey="quantity"
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Forma de Pagamento</TableHead>
                <TableHead>Quantidade</TableHead>
                <TableHead>Total</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((payment) => (
                <TableRow key={payment.method}>
                  <TableCell>{payment.method}</TableCell>
                  <TableCell>{payment.quantity}</TableCell>
                  <TableCell>R$ {payment.total.toFixed(2)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}

