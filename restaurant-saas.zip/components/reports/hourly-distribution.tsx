"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts'
import type { HourlyDistribution } from "@/types/reports"

const data: HourlyDistribution[] = [
  { hour: "04:30", orders: 1 },
  { hour: "16:24", orders: 1 },
  { hour: "16:25", orders: 1 }
]

export function HourlyDistribution() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Distribuição de Pedidos por Horário</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="hour" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="orders" name="Total de Pedidos" fill="#0ea5e9" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}

