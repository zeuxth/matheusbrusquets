"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { PieChart, Pie, Cell, ResponsiveContainer, Legend } from 'recharts'
import type { OrderStatus } from "@/types/reports"

const data: OrderStatus[] = [
  { status: "Em Preparo", count: 2, color: "#22c55e" },
  { status: "Entregue", count: 1, color: "#ef4444" },
  { status: "Pendente", count: 2, color: "#eab308" },
  { status: "Pronto para Entrega", count: 2, color: "#06b6d4" }
]

export function OrderStatusChart() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Status dos Pedidos</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={5}
                dataKey="count"
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}

