import { FileSpreadsheet, FileIcon as FilePdf } from 'lucide-react'
import { Button } from "@/components/ui/button"

export function ExportButtons() {
  return (
    <div className="flex gap-2">
      <Button variant="outline" className="bg-emerald-600 text-white hover:bg-emerald-700">
        <FileSpreadsheet className="mr-2 h-4 w-4" />
        Exportar Excel
      </Button>
      <Button variant="outline" className="bg-red-600 text-white hover:bg-red-700">
        <FilePdf className="mr-2 h-4 w-4" />
        Exportar PDF
      </Button>
    </div>
  )
}

