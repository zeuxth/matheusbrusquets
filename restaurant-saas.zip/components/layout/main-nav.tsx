"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { BarChart3, Home, Settings, ShoppingCart, ClipboardList, FileText, Workflow, Code, LogOut } from 'lucide-react'
import { useAuth } from '@/components/providers/auth-provider'
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

const items = [
  {
    title: "Dashboard",
    href: "/",
    icon: Home
  },
  {
    title: "Pedidos",
    href: "/pedidos",
    icon: ShoppingCart
  },
  {
    title: "Movimentação",
    href: "/movimentacao",
    icon: Workflow
  },
  {
    title: "POS",
    href: "/pos",
    icon: ClipboardList
  },
  {
    title: "Relatórios",
    href: "/relatorios",
    icon: FileText
  },
  {
    title: "Configurações",
    href: "/configuracoes",
    icon: Settings
  },
  {
    title: "Customização",
    href: "/customizacao",
    icon: BarChart3
  },
  {
    title: "EvolutionAPI",
    href: "/api",
    icon: Code
  }
]

export function MainNav() {
  const pathname = usePathname()
  const { user, logout } = useAuth()

  return (
    <div className="flex flex-col h-screen bg-red-600 text-white w-60">
      <div className="p-6">
        <h1 className="text-2xl font-bold">Delivery PRO</h1>
        {user && (
          <p className="text-sm mt-2 text-white/80">{user.name}</p>
        )}
      </div>
      <nav className="flex-1">
        {items.map((item) => (
          <Link key={item.href} href={item.href}>
            <Button
              variant="ghost"
              className={cn(
                "w-full justify-start gap-2 rounded-none text-white hover:bg-red-700",
                pathname === item.href && "bg-red-700"
              )}
            >
              <item.icon className="h-5 w-5" />
              {item.title}
            </Button>
          </Link>
        ))}
      </nav>
      <div className="p-6">
        <Button
          variant="ghost"
          className="w-full justify-start gap-2 text-white hover:bg-red-700"
          onClick={() => logout()}
        >
          <LogOut className="h-5 w-5" />
          Sair
        </Button>
      </div>
    </div>
  )
}

