import { useState, useEffect } from 'react'
import { MenuItem } from '@prisma/client'

interface MenuProps {
  restaurantId: string
}

export function Menu({ restaurantId }: MenuProps) {
  const [menuItems, setMenuItems] = useState<MenuItem[]>([])

  useEffect(() => {
    fetch(`/api/restaurants/${restaurantId}/menu`)
      .then(res => res.json())
      .then(data => setMenuItems(data))
  }, [restaurantId])

  return (
    <div className="container mx-auto px-4">
      <h1 className="text-3xl font-bold mb-4">Our Menu</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {menuItems.map(item => (
          <div key={item.id} className="border p-4 rounded-lg">
            <h2 className="text-xl font-semibold">{item.name}</h2>
            <p className="text-gray-600">{item.description}</p>
            <p className="text-lg font-bold mt-2">${item.price.toFixed(2)}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

