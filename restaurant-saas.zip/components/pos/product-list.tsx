"use client"

import { Button } from "@/components/ui/button"
import type { Category, Product } from "@/types/pos"

interface ProductListProps {
  categories: Category[]
  onAddToCart: (product: Product) => void
}

export function ProductList({ categories, onAddToCart }: ProductListProps) {
  return (
    <div className="space-y-6">
      {categories.map((category) => (
        <div key={category.name}>
          <h2 className="flex items-center gap-2 text-lg font-semibold text-red-600 mb-4">
            <span className="text-xl">{category.icon}</span>
            {category.name}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {category.products.map((product) => (
              <Button
                key={product.id}
                variant="outline"
                className="h-auto p-4 flex flex-col items-start gap-2"
                onClick={() => onAddToCart(product)}
              >
                <div className="flex items-center gap-2">
                  {product.icon && <span>{product.icon}</span>}
                  <span>{product.name}</span>
                </div>
                <span className="text-red-600 font-semibold">
                  R$ {product.price.toFixed(2)}
                </span>
              </Button>
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}

