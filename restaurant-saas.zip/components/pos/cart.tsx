"use client"

import { Trash2 } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useState } from 'react';
import type { CartItem } from "@/types/pos"

interface CartProps {
  items: CartItem[]
  onClearCart: () => void
  onFinishSale: () => void
  onUpdateTax?: (tax: number) => void
  onUpdateDiscount?: (discount: number) => void
}

export function Cart({ items, onClearCart, onFinishSale, onUpdateTax, onUpdateDiscount }: CartProps) {
  const [tax, setTax] = useState(0)
  const [discount, setDiscount] = useState(0)
  const subtotal = items.reduce((acc, item) => acc + item.price * item.quantity, 0)
  const total = subtotal + tax - discount

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold">Carrinho</h2>
      
      <div className="space-y-4">
        {items.map((item) => (
          <div key={item.id} className="flex items-center justify-between gap-2">
            <div className="flex-1">
              <div className="font-medium">{item.name}</div>
              <div className="text-sm text-muted-foreground">
                {item.quantity}x R$ {item.price.toFixed(2)}
              </div>
            </div>
            <div className="font-medium">
              R$ {(item.price * item.quantity).toFixed(2)}
            </div>
          </div>
        ))}
      </div>

      <div className="space-y-2">
        <div className="flex justify-between">
          <span>Subtotal:</span>
          <span>R$ {subtotal.toFixed(2)}</span>
        </div>
        
        <div className="grid grid-cols-2 gap-2">
          <div className="space-y-1.5">
            <Label>Taxa</Label>
            <Input
              type="number"
              value={tax}
              onChange={(e) => {setTax(Number(e.target.value)); onUpdateTax && onUpdateTax(Number(e.target.value))}}
              step="0.01"
              min="0"
              className="text-right"
            />
          </div>
          <div className="space-y-1.5">
            <Label>Desconto</Label>
            <Input
              type="number"
              value={discount}
              onChange={(e) => {setDiscount(Number(e.target.value)); onUpdateDiscount && onUpdateDiscount(Number(e.target.value))}}
              step="0.01"
              min="0"
              className="text-right"
            />
          </div>
        </div>

        <div className="flex justify-between font-semibold">
          <span>Total:</span>
          <span>R$ {total.toFixed(2)}</span>
        </div>
      </div>

      <div className="space-y-2">
        <Button
          className="w-full bg-emerald-600 hover:bg-emerald-700"
          onClick={onFinishSale}
        >
          Finalizar Venda
        </Button>
        <Button
          variant="destructive"
          className="w-full"
          onClick={onClearCart}
        >
          <Trash2 className="mr-2 h-4 w-4" />
          Limpar Carrinho
        </Button>
      </div>
    </div>
  )
}

