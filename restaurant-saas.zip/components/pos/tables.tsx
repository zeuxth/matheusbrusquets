"use client"

import { Utensils } from 'lucide-react'
import { Button } from "@/components/ui/button"
import type { Table } from "@/types/pos"

interface TablesProps {
  tables: Table[]
  onSelectTable: (table: Table) => void
}

export function Tables({ tables, onSelectTable }: TablesProps) {
  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold">Mesas</h2>
      <div className="grid grid-cols-3 gap-4">
        {tables.map((table) => (
          <Button
            key={table.id}
            variant="outline"
            className={`h-24 flex flex-col items-center justify-center gap-2 ${
              table.status === "occupied" ? "bg-red-100 border-red-200" : ""
            }`}
            onClick={() => onSelectTable(table)}
          >
            <Utensils className={`h-6 w-6 ${
              table.status === "occupied" ? "text-red-600" : "text-gray-400"
            }`} />
            <div className="text-center">
              <div className="font-medium">{table.name}</div>
              {table.status === "occupied" && (
                <div className="text-sm text-red-600">Ocupada</div>
              )}
            </div>
          </Button>
        ))}
      </div>
    </div>
  )
}

