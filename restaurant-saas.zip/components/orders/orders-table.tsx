import { Ban, Eye, Printer, Trash2 } from 'lucide-react'
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Order } from "@/types/orders"

const statusMap = {
  "Pendente": { color: "bg-yellow-200 text-yellow-700" },
  "Em Preparo": { color: "bg-blue-200 text-blue-700" },
  "Pronto para Entrega": { color: "bg-emerald-200 text-emerald-700" },
  "Entregue": { color: "bg-gray-200 text-gray-700" }
}

interface OrdersTableProps {
  orders: Order[]
}

export function OrdersTable({ orders }: OrdersTableProps) {
  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Cliente</TableHead>
            <TableHead>Telefone</TableHead>
            <TableHead>Endereço</TableHead>
            <TableHead>Pedido</TableHead>
            <TableHead>Itens</TableHead>
            <TableHead>Total</TableHead>
            <TableHead>Pagamento</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Data</TableHead>
            <TableHead>Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {orders.map((order) => (
            <TableRow key={order.id}>
              <TableCell>
                <div className="flex items-center gap-2">
                  {order.isPOS && (
                    <Badge variant="outline" className="bg-red-100 text-red-700 border-red-200">
                      POS
                    </Badge>
                  )}
                  {order.tableNumber && (
                    <Badge variant="outline" className="bg-yellow-100 text-yellow-700 border-yellow-200">
                      Mesa {order.tableNumber}
                    </Badge>
                  )}
                  {order.customer.name}
                </div>
              </TableCell>
              <TableCell>{order.customer.phone || "Não informado"}</TableCell>
              <TableCell>
                {order.customer.address ? 
                  `${order.customer.address.street}, ${order.customer.address.neighborhood}` : 
                  "Não informado"
                }
              </TableCell>
              <TableCell>#{order.id}</TableCell>
              <TableCell>
                {order.items.map((item) => (
                  <div key={item.name}>
                    {item.quantity}x {item.name}
                  </div>
                ))}
              </TableCell>
              <TableCell>R$ {order.total.toFixed(2)}</TableCell>
              <TableCell>{order.paymentMethod}</TableCell>
              <TableCell>
                <Badge className={statusMap[order.status].color}>
                  {order.status}
                </Badge>
              </TableCell>
              <TableCell>
                {new Date(order.createdAt).toLocaleString('pt-BR')}
              </TableCell>
              <TableCell>
                <div className="flex gap-2">
                  <Button size="icon" variant="ghost">
                    <Printer className="h-4 w-4" />
                  </Button>
                  <Button size="icon" variant="ghost">
                    <Eye className="h-4 w-4" />
                  </Button>
                  <Button size="icon" variant="ghost" className="text-red-600">
                    <Ban className="h-4 w-4" />
                  </Button>
                  <Button size="icon" variant="ghost" className="text-red-600">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

