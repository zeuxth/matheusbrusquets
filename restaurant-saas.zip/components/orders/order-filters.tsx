"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

export function OrderFilters() {
  return (
    <div className="flex flex-col gap-4 md:flex-row md:items-end">
      <div className="grid gap-2 flex-1">
        <Input placeholder="Nome do Cliente" />
      </div>
      <div className="grid gap-2 flex-1">
        <Input placeholder="Telefone" />
      </div>
      <div className="grid gap-2 flex-1">
        <Select>
          <SelectTrigger>
            <SelectValue placeholder="Todos os Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="pending">Pendente</SelectItem>
            <SelectItem value="preparing">Em Preparo</SelectItem>
            <SelectItem value="ready">Pronto para Entrega</SelectItem>
            <SelectItem value="delivered">Entregue</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="grid gap-2 flex-1">
        <Select>
          <SelectTrigger>
            <SelectValue placeholder="Todas as Formas de Pagamento" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="cash">Dinheiro</SelectItem>
            <SelectItem value="card">Cartão</SelectItem>
            <SelectItem value="pending">Pendente</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="flex gap-2">
        <Button className="flex-1 bg-red-600 hover:bg-red-700">Filtrar</Button>
        <Button variant="outline" className="flex-1">
          Limpar Filtros
        </Button>
      </div>
    </div>
  )
}

