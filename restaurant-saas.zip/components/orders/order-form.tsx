"use client"

import { Plus } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

export function OrderForm() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-red-600">Cadastro Manual de Pedido</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <div>
            <Label>Selecionar Cliente Cadastrado</Label>
            <div className="flex gap-2">
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Novo cliente ou selecione um cliente..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="new">Novo Cliente</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline">Limpar</Button>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label>Nome do Cliente</Label>
              <Input />
            </div>
            <div className="space-y-2">
              <Label>Telefone</Label>
              <Input />
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label>CEP</Label>
              <Input />
            </div>
            <div className="space-y-2">
              <Label>Rua</Label>
              <Input />
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label>Bairro</Label>
              <Input />
            </div>
            <div className="space-y-2">
              <Label>Complemento</Label>
              <Input />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Itens do Pedido</Label>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Selecione um produto..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="product1">Produto 1</SelectItem>
                <SelectItem value="product2">Produto 2</SelectItem>
              </SelectContent>
            </Select>
            <Button className="mt-2" variant="outline">
              <Plus className="mr-2 h-4 w-4" />
              Adicionar Produto
            </Button>
          </div>

          <div className="space-y-2">
            <Label>Região de Entrega</Label>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Selecione a região..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="region1">Região 1</SelectItem>
                <SelectItem value="region2">Região 2</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Forma de Pagamento</Label>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Selecione..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="cash">Dinheiro</SelectItem>
                <SelectItem value="card">Cartão</SelectItem>
                <SelectItem value="pending">Pendente</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2">
              <Label>Sub Total</Label>
              <Input readOnly />
            </div>
            <div className="space-y-2">
              <Label>Taxa de Entrega</Label>
              <Input />
            </div>
            <div className="space-y-2">
              <Label>Total</Label>
              <Input readOnly />
            </div>
          </div>
        </div>

        <Button className="w-full bg-red-600 hover:bg-red-700">
          Cadastrar Pedido
        </Button>
      </CardContent>
    </Card>
  )
}

