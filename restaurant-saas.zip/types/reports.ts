export interface SalesData {
  date: string
  total: number
}

export interface OrderStatus {
  status: string
  count: number
  color: string
}

export interface ProductSales {
  name: string
  quantity: number
  total: number
  icon?: string
}

export interface PaymentMethod {
  method: string
  quantity: number
  total: number
  color: string
}

export interface Neighborhood {
  name: string
  orders: number
  total: number
}

export interface HourlyDistribution {
  hour: string
  orders: number
}

export interface FinancialKPI {
  totalRevenue: number
  averageTicket: number
  deliveryCosts: number
}

export interface MonthlyProfitability {
  month: string
  grossRevenue: number
  deliveryCosts: number
  netRevenue: number
  profitMargin: number
}

export interface EarningsCalendar {
  month: string
  orders: number
  sales: number
  fees: number
  total: number
  averagePerOrder: number
}

