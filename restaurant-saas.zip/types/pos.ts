export interface Product {
  id: string
  name: string
  price: number
  category: string
  icon?: string
}

export interface CartItem extends Product {
  quantity: number
}

export interface Table {
  id: number
  name: string
  status: "available" | "occupied"
  order?: {
    items: CartItem[]
    total: number
  }
}

export interface Category {
  name: string
  icon: string
  products: Product[]
}

