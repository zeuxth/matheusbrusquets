export interface DeliveryRegion {
  name: string
  fee: number
}

export interface DeliveryPerson {
  name: string
  phone: string
  vehicle: string
  status: "Ativo" | "Em Entrega"
}

export interface Delivery {
  id: string
  customer: {
    name: string
    phone: string
  }
  address: string
  deliveryPerson?: string
  status: "Em Rota" | "Aguardando" | "Entregue"
  time?: string
  fee?: number
}

export interface BusinessHours {
  start: string
  end: string
  workingDays: string[]
}

