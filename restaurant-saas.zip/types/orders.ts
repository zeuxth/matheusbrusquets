export interface Customer {
  name: string
  phone: string
  address?: {
    cep: string
    street: string
    neighborhood: string
    complement?: string
    region?: string
  }
}

export interface OrderItem {
  name: string
  quantity: number
  price: number
}

export type PaymentMethod = "Dinheiro" | "Cartão" | "Pendente de Pagamento"
export type OrderStatus = "Pendente" | "Em Preparo" | "Pronto para Entrega" | "Entregue"

export interface Order {
  id: string
  customer: Customer
  items: OrderItem[]
  total: number
  paymentMethod: PaymentMethod
  status: OrderStatus
  createdAt: Date
  isPOS?: boolean
  tableNumber?: string
}

